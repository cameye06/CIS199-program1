﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totaCostLable = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.laborCostLable = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.paintCostLable = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.hoursLable = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gallonsLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.totalFeetLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gallonBox = new System.Windows.Forms.TextBox();
            this.coatsBox = new System.Windows.Forms.TextBox();
            this.feetBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // totaCostLable
            // 
            this.totaCostLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totaCostLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totaCostLable.Location = new System.Drawing.Point(170, 267);
            this.totaCostLable.Name = "totaCostLable";
            this.totaCostLable.Size = new System.Drawing.Size(128, 17);
            this.totaCostLable.TabIndex = 39;
            this.totaCostLable.Text = " ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 268);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "Total cost of paint job:";
            // 
            // laborCostLable
            // 
            this.laborCostLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCostLable.Location = new System.Drawing.Point(170, 243);
            this.laborCostLable.Name = "laborCostLable";
            this.laborCostLable.Size = new System.Drawing.Size(128, 17);
            this.laborCostLable.TabIndex = 37;
            this.laborCostLable.Text = " ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(95, 244);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "Cost of labor:";
            // 
            // paintCostLable
            // 
            this.paintCostLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCostLable.Location = new System.Drawing.Point(170, 220);
            this.paintCostLable.Name = "paintCostLable";
            this.paintCostLable.Size = new System.Drawing.Size(128, 17);
            this.paintCostLable.TabIndex = 35;
            this.paintCostLable.Text = " ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(95, 221);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 34;
            this.label7.Text = "Cost of paint:";
            // 
            // hoursLable
            // 
            this.hoursLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursLable.Location = new System.Drawing.Point(170, 196);
            this.hoursLable.Name = "hoursLable";
            this.hoursLable.Size = new System.Drawing.Size(128, 17);
            this.hoursLable.TabIndex = 33;
            this.hoursLable.Text = " ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(88, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 32;
            this.label6.Text = "Hours of labor:";
            // 
            // gallonsLabel
            // 
            this.gallonsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsLabel.Location = new System.Drawing.Point(170, 173);
            this.gallonsLabel.Name = "gallonsLabel";
            this.gallonsLabel.Size = new System.Drawing.Size(128, 17);
            this.gallonsLabel.TabIndex = 31;
            this.gallonsLabel.Text = " ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Gallons of paint required:";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(124, 100);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(71, 26);
            this.calcButton.TabIndex = 29;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // totalFeetLabel
            // 
            this.totalFeetLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalFeetLabel.Location = new System.Drawing.Point(170, 149);
            this.totalFeetLabel.Name = "totalFeetLabel";
            this.totalFeetLabel.Size = new System.Drawing.Size(128, 17);
            this.totalFeetLabel.TabIndex = 28;
            this.totalFeetLabel.Text = " ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(74, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Total square feet:";
            // 
            // gallonBox
            // 
            this.gallonBox.Location = new System.Drawing.Point(170, 74);
            this.gallonBox.Name = "gallonBox";
            this.gallonBox.Size = new System.Drawing.Size(96, 20);
            this.gallonBox.TabIndex = 26;
            // 
            // coatsBox
            // 
            this.coatsBox.Location = new System.Drawing.Point(170, 48);
            this.coatsBox.Name = "coatsBox";
            this.coatsBox.Size = new System.Drawing.Size(96, 20);
            this.coatsBox.TabIndex = 25;
            // 
            // feetBox
            // 
            this.feetBox.Location = new System.Drawing.Point(170, 22);
            this.feetBox.Name = "feetBox";
            this.feetBox.Size = new System.Drawing.Size(96, 20);
            this.feetBox.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Price of paint per gallon:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Number of coats of paint:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Square feet to paint:";
            // 
            // Program1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 307);
            this.Controls.Add(this.totaCostLable);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.laborCostLable);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.paintCostLable);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.hoursLable);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gallonsLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.totalFeetLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gallonBox);
            this.Controls.Add(this.coatsBox);
            this.Controls.Add(this.feetBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Program1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label totaCostLable;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label laborCostLable;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label paintCostLable;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label hoursLable;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label gallonsLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label totalFeetLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox gallonBox;
        private System.Windows.Forms.TextBox coatsBox;
        private System.Windows.Forms.TextBox feetBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

