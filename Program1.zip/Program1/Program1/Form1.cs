﻿
/* 
 * B8426
 * CIS 199
 * section 2
 * Program 1
 * due: 2/14/2017
 * 
 * 
 * This program takes total square feet, coats of paint, and cost of paint as inputs 
 * then outputs total square feet painted, gallons of paint required, hours of labor required, cost of paint,
 * cost of labor, and then total cost *  
 * 
 */
 
 using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            float Feet; // holds the square feet of what is needed to be painted
            int Coats; // holds how many coats of paint are being used
            float GPrice; // holds the price of paint per gallon
           
            Feet = float.Parse(feetBox.Text); // sets the Feet float to what is entered into feetBox
            Coats = int.Parse(coatsBox.Text); // sets the Coats int to what is entered into coatsBox
            GPrice = float.Parse(gallonBox.Text); // set Gallon float to what is entered into gallonBox

            double TFeet = Feet*Coats; // double to hold total feet painted (feet * # of coats)
            double TGallon = TFeet/330; // double to hold total gallons needed (one gal per 33 ft)
            double THours = TGallon*6; // double to hof total hours of work (6 hours per gallon)

            TGallon = Math.Ceiling(TGallon); // uses Math.Ceiling to round TGallon up to whole number

            double TGPrice = GPrice * TGallon; // double to hold price of paint (price per gal * total Gal)
            double TLaborC = THours * 10.5;  //double to hold total labor cost (total hours * 10.5)
            double Total = TGPrice + TLaborC; // double to hold total cost (paint cost + labor cost)

            totalFeetLabel.Text = TFeet.ToString("f1")+" sq. ft."; // prints TFeet to totalFeetLabel (with one dec place)
            gallonsLabel.Text =  TGallon.ToString()+" gal.";   // prints TGallon to gallonsLable    
            hoursLable.Text = THours.ToString("f1")+ " hours";  // prints THours fo hoursLable (with one dec place)
            paintCostLable.Text = TGPrice.ToString("C");  // prints TGPrice to paitCostLable
            laborCostLable.Text = TLaborC.ToString("c");  // prints TLaborC to laborCostLable
            totaCostLable.Text = Total.ToString("c");  // prints Total to totalCostLable


        }
    }
}
